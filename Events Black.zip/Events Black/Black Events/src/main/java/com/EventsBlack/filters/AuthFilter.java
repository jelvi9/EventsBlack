package com.darwinruiz.shoplite.filters;
import jakarta.servlet.*;import jakarta.servlet.http.*;import java.io.IOException;
public class AuthFilter implements Filter{public void doFilter(ServletRequest req,ServletResponse res,FilterChain chain)throws IOException,ServletException{
HttpServletRequest r=(HttpServletRequest)req;HttpServletResponse p=(HttpServletResponse)res;HttpSession s=r.getSession(false);boolean ok=s!=null&&Boolean.TRUE.equals(s.getAttribute("auth"));
if(!ok){p.sendRedirect(r.getContextPath()+"/login.jsp?err=auth");return;}chain.doFilter(req,res);}}