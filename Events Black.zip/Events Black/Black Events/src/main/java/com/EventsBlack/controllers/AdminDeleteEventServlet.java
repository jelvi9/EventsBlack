package com.darwinruiz.shoplite.controllers;
import com.darwinruiz.shoplite.repositories.EventRepository;import jakarta.servlet.annotation.WebServlet;import jakarta.servlet.http.*;import java.io.IOException;
@WebServlet(name="AdminDeleteEventServlet",urlPatterns="/admin/delete-event")
public class AdminDeleteEventServlet extends HttpServlet{protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws IOException{
try{int id=Integer.parseInt(req.getParameter("id"));EventRepository.deleteById(id);resp.sendRedirect(req.getContextPath()+"/admin/events?deleted=1");}
catch(Exception e){resp.sendRedirect(req.getContextPath()+"/admin/events?err=1");}}}