package com.darwinruiz.shoplite.controllers;
import com.darwinruiz.shoplite.models.User;import com.darwinruiz.shoplite.repositories.UserRepository;
import jakarta.servlet.ServletException;import jakarta.servlet.annotation.WebServlet;import jakarta.servlet.http.*;import java.io.IOException;import java.time.LocalDateTime;import java.time.format.DateTimeFormatter;import java.util.Optional;
@WebServlet(name="LoginServlet",urlPatterns="/auth/login")
public class LoginServlet extends HttpServlet{
protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
String email=req.getParameter("email");String password=req.getParameter("password");
Optional<User> u=UserRepository.findByEmail(email);
if(u.isEmpty()||!u.get().getPassword().equals(password)){resp.sendRedirect(req.getContextPath()+"/login.jsp?err=1");return;}
HttpSession old=req.getSession(false);if(old!=null)old.invalidate();
HttpSession s=req.getSession(true);s.setAttribute("auth",true);s.setAttribute("userEmail",u.get().getEmail());s.setAttribute("role",u.get().getRole());s.setMaxInactiveInterval(30*60);
String now=LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
Cookie c=new Cookie("lastLogin",now);c.setHttpOnly(true);c.setPath(req.getContextPath().isEmpty()?"/":req.getContextPath());resp.addCookie(c);
resp.sendRedirect(req.getContextPath()+"/events");
}}