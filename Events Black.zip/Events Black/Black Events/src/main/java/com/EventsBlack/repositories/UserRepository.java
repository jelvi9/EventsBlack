package com.darwinruiz.shoplite.repositories;
import com.darwinruiz.shoplite.models.User;import java.util.*;import java.util.concurrent.atomic.AtomicInteger;
public class UserRepository{private static final List<User> USERS=Collections.synchronizedList(new ArrayList<>());private static final AtomicInteger SEQ=new AtomicInteger(1);
static{save(new User(0,"Admin","admin@demo.com","admin123","ADMIN"));save(new User(0,"Usuario","user@demo.com","user123","USER"));}
public static List<User> findAll(){synchronized(USERS){return new ArrayList<>(USERS);}}
public static Optional<User> findByEmail(String email){if(email==null)return Optional.empty();synchronized(USERS){return USERS.stream().filter(u->email.equalsIgnoreCase(u.getEmail())).findFirst();}}
public static void save(User u){if(u.getId()==0)u.setId(nextId());synchronized(USERS){for(int i=0;i<USERS.size();i++){if(USERS.get(i).getEmail().equalsIgnoreCase(u.getEmail())){USERS.set(i,u);return;}}USERS.add(u);}}
public static int nextId(){return SEQ.getAndIncrement();}
}