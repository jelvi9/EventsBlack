package com.darwinruiz.shoplite.controllers;
import com.darwinruiz.shoplite.models.User;import com.darwinruiz.shoplite.repositories.UserRepository;
import jakarta.servlet.ServletException;import jakarta.servlet.annotation.WebServlet;import jakarta.servlet.http.*;import java.io.IOException;
@WebServlet(name="RegisterServlet",urlPatterns="/auth/register")
public class RegisterServlet extends HttpServlet{protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
String name=req.getParameter("name"),email=req.getParameter("email"),password=req.getParameter("password"),role=req.getParameter("role");if(role==null||role.isBlank())role="USER";
if(name==null||email==null||password==null||name.isBlank()||email.isBlank()||password.isBlank()){resp.sendRedirect(req.getContextPath()+"/register.jsp?err=1");return;}
User u=new User(0,name,email,password,role);UserRepository.save(u);resp.sendRedirect(req.getContextPath()+"/login.jsp?ok=1");}}