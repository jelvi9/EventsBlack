package com.darwinruiz.shoplite.controllers;
import com.darwinruiz.shoplite.repositories.EventRepository;import jakarta.servlet.ServletException;import jakarta.servlet.annotation.WebServlet;import jakarta.servlet.http.*;import java.io.IOException;
@WebServlet(name="EventsServlet",urlPatterns="/events")
public class EventsServlet extends HttpServlet{protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
req.setAttribute("events",EventRepository.findAll());req.getRequestDispatcher("/events.jsp").forward(req,resp);}}