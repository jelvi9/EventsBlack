package com.darwinruiz.shoplite.controllers;
import com.darwinruiz.shoplite.models.Event;import com.darwinruiz.shoplite.repositories.EventRepository;import jakarta.servlet.ServletException;import jakarta.servlet.annotation.WebServlet;import jakarta.servlet.http.*;import java.io.IOException;import java.time.LocalDate;
@WebServlet(name="AdminEventsServlet",urlPatterns="/admin/events")
public class AdminEventsServlet extends HttpServlet{protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
req.setAttribute("events",EventRepository.findAll());req.getRequestDispatcher("/admin/events.jsp").forward(req,resp);}protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws IOException{
try{EventRepository.save(new Event(0,req.getParameter("name"),java.time.LocalDate.parse(req.getParameter("date")),req.getParameter("location")));resp.sendRedirect(req.getContextPath()+"/admin/events?ok=1");}
catch(Exception e){resp.sendRedirect(req.getContextPath()+"/admin/events?err=1");}}}