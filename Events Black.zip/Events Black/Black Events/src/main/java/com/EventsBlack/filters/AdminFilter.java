package com.darwinruiz.shoplite.filters;
import jakarta.servlet.*;import jakarta.servlet.http.*;import java.io.IOException;
public class AdminFilter implements Filter{public void doFilter(ServletRequest req,ServletResponse res,FilterChain chain)throws IOException,ServletException{
HttpServletRequest r=(HttpServletRequest)req;HttpServletResponse p=(HttpServletResponse)res;HttpSession s=r.getSession(false);String role=s!=null?(String)s.getAttribute("role"):null;
if(!"ADMIN".equals(role)){r.getRequestDispatcher("/403.jsp").forward(r,p);return;}chain.doFilter(req,res);}}