package com.darwinruiz.shoplite.repositories;
import com.darwinruiz.shoplite.models.Event;import java.time.LocalDate;import java.util.*;import java.util.concurrent.atomic.AtomicInteger;
public class EventRepository{private static final List<Event> EVENTS=Collections.synchronizedList(new ArrayList<>());private static final AtomicInteger SEQ=new AtomicInteger(1);
static{save(new Event(0,"Charla de Innovación",LocalDate.now().plusDays(2),"Auditorio A"));save(new Event(0,"Feria de Empleo",LocalDate.now().plusWeeks(1),"Gimnasio"));}
public static List<Event> findAll(){synchronized(EVENTS){return new ArrayList<>(EVENTS);}}
public static void save(Event e){if(e.getId()==0)e.setId(nextId());synchronized(EVENTS){for(int i=0;i<EVENTS.size();i++){if(EVENTS.get(i).getId()==e.getId()){EVENTS.set(i,e);return;}}EVENTS.add(e);}}
public static void deleteById(int id){synchronized(EVENTS){EVENTS.removeIf(ev->ev.getId()==id);}}
public static int nextId(){return SEQ.getAndIncrement();}
}